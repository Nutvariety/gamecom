# Cyber Buddy AR

เกมการศึกษา AR วิชาคอมพิวเตอร์สำหรับฝึกทักษะการรู้จักและจำแนกอุปกรณ์คอมพิวเตอร์

## วิธีเผยแพร่ด้วย GitHub Pages
1. อัปโหลดไฟล์ `index.html` ไปยัง repository
2. ไปที่ Settings > Pages
3. Source: Deploy from a branch
4. Branch: main
5. Folder: /(root)
6. กด Save

เกมใช้กล้องผ่าน WebRTC และระบบตรวจจับท่ามือผ่าน MediaPipe จึงควรเปิดผ่าน HTTPS (GitHub Pages รองรับ)

เครดิต: พัฒนาโดย ครูนัท พัชรากร
